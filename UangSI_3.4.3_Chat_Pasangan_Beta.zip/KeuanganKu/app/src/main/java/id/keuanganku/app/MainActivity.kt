package id.keuanganku.app

import android.os.Bundle
import android.content.Context
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.*
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "transactions")
data class FinanceTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Long,
    val type: String,
    val category: String,
    val date: Long = System.currentTimeMillis(),
    val note: String = "",
    val cloudDocId: String? = null
)

@Entity(tableName = "wallets")
data class Wallet(
    @PrimaryKey val id: String,
    val name: String,
    val owner: String,
    val openingBalance: Long = 0L,
    val kind: String = "Pribadi",
    val cloudDocId: String? = null
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey val category: String,
    val limitAmount: Long,
    val cloudDocId: String? = null
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    suspend fun allTransactions(): List<FinanceTransaction>
    @Insert suspend fun insert(t: FinanceTransaction): Long
    @Update suspend fun update(t: FinanceTransaction)
    @Delete suspend fun delete(t: FinanceTransaction)
    @Query("SELECT * FROM budgets")
    suspend fun allBudgets(): List<Budget>
    @Query("SELECT * FROM wallets ORDER BY owner, name")
    suspend fun allWallets(): List<Wallet>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveWallet(wallet: Wallet)
    @Query("DELETE FROM wallets WHERE cloudDocId IS NOT NULL") suspend fun clearCloudWallets()
    @Query("SELECT * FROM wallets WHERE cloudDocId IS NULL") suspend fun localWallets(): List<Wallet>
    @Query("UPDATE wallets SET cloudDocId = :cloudId WHERE id = :localId") suspend fun setWalletCloudId(localId: String, cloudId: String)
    @Delete suspend fun deleteWallet(wallet: Wallet)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveBudget(b: Budget)
    @Query("DELETE FROM budgets WHERE cloudDocId IS NOT NULL") suspend fun clearCloudBudgets()
    @Query("SELECT * FROM budgets WHERE cloudDocId IS NULL") suspend fun localBudgets(): List<Budget>
    @Query("UPDATE budgets SET cloudDocId = :cloudId WHERE category = :category") suspend fun setBudgetCloudId(category: String, cloudId: String)
    @Query("DELETE FROM transactions") suspend fun clearTransactions()
    @Query("DELETE FROM budgets") suspend fun clearBudgets()
    @Query("DELETE FROM wallets") suspend fun clearAllWallets()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTransactions(items: List<FinanceTransaction>)
    @Query("DELETE FROM transactions WHERE cloudDocId IS NOT NULL") suspend fun clearCloudTransactions()
    @Query("SELECT * FROM transactions WHERE cloudDocId IS NULL") suspend fun localTransactions(): List<FinanceTransaction>
    @Query("UPDATE transactions SET cloudDocId = :cloudId WHERE id = :localId") suspend fun setTransactionCloudId(localId: Long, cloudId: String)
    @Query("SELECT * FROM transactions WHERE cloudDocId = :cloudId LIMIT 1") suspend fun transactionByCloudId(cloudId: String): FinanceTransaction?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBudgets(items: List<Budget>)
}

data class FinanceBackup(
    val format: String = "KeuanganKuBackup",
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val transactions: List<FinanceTransaction>,
    val budgets: List<Budget>
)

@Database(entities = [FinanceTransaction::class, Budget::class, Wallet::class], version = 4, exportSchema = false)
abstract class FinanceDb : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS wallets (id TEXT NOT NULL, name TEXT NOT NULL, owner TEXT NOT NULL, openingBalance INTEGER NOT NULL, kind TEXT NOT NULL, PRIMARY KEY(id))")
            }
        }
        val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE transactions ADD COLUMN cloudDocId TEXT")
            }
        }
        val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE wallets ADD COLUMN cloudDocId TEXT")
                db.execSQL("ALTER TABLE budgets ADD COLUMN cloudDocId TEXT")
            }
        }
        @Volatile private var INSTANCE: FinanceDb? = null
        fun get(context: android.content.Context): FinanceDb =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context, FinanceDb::class.java, "keuanganku.db").addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { INSTANCE = it }
            }
    }
}

private val navy = Color(0xFF142B4A)
private val navyLight = Color(0xFF244B70)
private val teal = Color(0xFF19A89A)
private val pale = Color(0xFFF3F7FA)
private val green = Color(0xFF16845B)
private val red = Color(0xFFD94B4B)
private val muted = Color(0xFF718096)
private fun rupiah(v: Long): String = NumberFormat.getCurrencyInstance(Locale("in","ID")).format(v).replace(",00","")
private fun monthStart(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0)
    return c.timeInMillis
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = navy, secondary = teal, background = pale, surface = Color.White)) { UangSiRoot(this) } }
    }
}

@Composable
private fun UangSiRoot(activity: ComponentActivity) {
    val auth = remember { com.google.firebase.auth.FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(auth) {
        val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    if (user == null) {
        AuthScreen(auth)
    } else {
        val uid = user!!.uid
        val dao = remember(uid) { Room.databaseBuilder(activity, FinanceDb::class.java, "uangsi_$uid.db").addMigrations(FinanceDb.MIGRATION_1_2, FinanceDb.MIGRATION_2_3, FinanceDb.MIGRATION_3_4).build().dao() }
        FinanceApp(dao, uid)
    }
}

@Composable
private fun AuthScreen(auth: com.google.firebase.auth.FirebaseAuth) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(navy, navyLight, Color(0xFFEAF4F5))))) {
        Column(Modifier.fillMaxWidth().align(Alignment.Center).padding(horizontal = 24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Box(Modifier.size(76.dp).background(Color.White.copy(alpha=.15f), RoundedCornerShape(24.dp)), contentAlignment=Alignment.Center) {
                Icon(Icons.Default.AccountBalanceWallet, null, tint=Color.White, modifier=Modifier.size(40.dp))
            }
            Text("Uang SI", fontSize=34.sp, fontWeight=FontWeight.ExtraBold, color=Color.White, modifier=Modifier.padding(top=14.dp))
            Text("Keuangan lebih rapi, rumah tangga lebih tenang", color=Color.White.copy(alpha=.82f), fontSize=13.sp)
            Spacer(Modifier.height(28.dp))
            Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(28.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(8.dp)) {
                Column(Modifier.padding(22.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text(if(register) "Buat akun baru" else "Selamat datang kembali", fontSize=22.sp, fontWeight=FontWeight.Bold, color=navy)
                    Text(if(register) "Mulai atur keuangan keluarga bersama." else "Masuk untuk melihat catatan keuangan Anda.", fontSize=13.sp, color=muted)
                    OutlinedTextField(email, { email=it }, Modifier.fillMaxWidth(), label={Text("Alamat email")}, leadingIcon={Icon(Icons.Default.Email, null)}, singleLine=true, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email), shape=RoundedCornerShape(14.dp))
                    OutlinedTextField(password, { password=it }, Modifier.fillMaxWidth(), label={Text("Password (minimal 6 karakter)")}, leadingIcon={Icon(Icons.Default.Lock, null)}, singleLine=true, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password), shape=RoundedCornerShape(14.dp))
                    Button(onClick={
                        if (email.isBlank() || password.length < 6) { message="Masukkan email valid dan password minimal 6 karakter."; return@Button }
                        busy=true; message=""
                        val task = if (register) auth.createUserWithEmailAndPassword(email.trim(), password) else auth.signInWithEmailAndPassword(email.trim(), password)
                        task.addOnCompleteListener { result -> busy=false; if (!result.isSuccessful) message=result.exception?.localizedMessage ?: "Autentikasi gagal." }
                    }, enabled=!busy, modifier=Modifier.fillMaxWidth().height(52.dp), shape=RoundedCornerShape(15.dp)) { Text(if (busy) "Memproses..." else if(register) "Daftar akun" else "Masuk", fontWeight=FontWeight.Bold) }
                    TextButton(onClick={register=!register; message=""}, modifier=Modifier.align(Alignment.CenterHorizontally)) { Text(if(register) "Sudah punya akun? Masuk" else "Belum punya akun? Daftar") }
                    if (message.isNotBlank()) Text(message, color=red, fontSize=12.sp)
                }
            }
            Text("Dirancang untuk suami dan istri", color=navy, fontSize=12.sp, modifier=Modifier.padding(top=18.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceApp(dao: FinanceDao, userId: String) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf(emptyList<FinanceTransaction>()) }
    var budgets by remember { mutableStateOf(emptyList<Budget>()) }
    var wallets by remember { mutableStateOf(emptyList<Wallet>()) }
    var page by remember { mutableStateOf("Beranda") }
    var showForm by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FinanceTransaction?>(null) }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Semua") }
    var pinEnabled by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<FinanceBackup?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val backup = FinanceBackup(transactions = dao.allTransactions(), budgets = dao.allBudgets())
                val json = Gson().toJson(backup)
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                        ?: error("File tujuan tidak dapat dibuka.")
                }
            }.onSuccess { backupMessage = "Backup berhasil disimpan." }
             .onFailure { backupMessage = "Gagal membuat backup: ${it.message ?: "kesalahan tidak diketahui"}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val json = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("File tidak dapat dibaca.")
                }
                val backup = Gson().fromJson(json, FinanceBackup::class.java) ?: error("Format file tidak valid.")
                validateBackup(backup)
                backup
            }.onSuccess { pendingRestore = it }
             .onFailure { backupMessage = "Backup ditolak: ${it.message ?: "file tidak valid"}" }
        }
    }

    suspend fun refresh() { rows = dao.allTransactions(); budgets = dao.allBudgets(); wallets = dao.allWallets() }
    LaunchedEffect(Unit) { refresh() }

    // Sinkronisasi transaksi lintas perangkat dalam satu rumah tangga.
    var syncStatus by remember { mutableStateOf("Memeriksa rumah tangga…") }
    DisposableEffect(userId, dao) {
        val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance()
        var householdListener: com.google.firebase.firestore.ListenerRegistration? = null
        var transactionListener: com.google.firebase.firestore.ListenerRegistration? = null
        var walletListener: com.google.firebase.firestore.ListenerRegistration? = null
        var budgetListener: com.google.firebase.firestore.ListenerRegistration? = null
        householdListener = firestore.collection("users").document(userId).addSnapshotListener { userDoc, userError ->
            if (userError != null) { syncStatus = "Sinkronisasi tertunda: ${userError.localizedMessage}"; return@addSnapshotListener }
            val hid = userDoc?.getString("householdId")
            if (hid.isNullOrBlank()) { syncStatus = "Belum terhubung ke rumah tangga"; transactionListener?.remove(); transactionListener = null; walletListener?.remove(); walletListener = null; budgetListener?.remove(); budgetListener = null; return@addSnapshotListener }
            syncStatus = "Menghubungkan data keluarga…"
            val txRef = firestore.collection("households").document(hid).collection("transactions")
            // Kirim transaksi lokal milik akun ini menggunakan ID dokumen stabil.
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                runCatching {
                    dao.localTransactions().forEach { t ->
                        val docId = "${userId}_${t.id}"
                        txRef.document(docId).set(mapOf(
                            "title" to t.title, "amount" to t.amount, "type" to t.type,
                            "category" to t.category, "date" to t.date, "note" to t.note,
                            "createdBy" to userId, "localId" to t.id,
                            "updatedBy" to userId, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                        ), com.google.firebase.firestore.SetOptions.merge()).await()
                        dao.setTransactionCloudId(t.id, docId)
                    }
                }.onFailure { syncStatus = "Gagal mengirim transaksi: ${it.localizedMessage}" }
            }
            val walletRef = firestore.collection("households").document(hid).collection("wallets")
            val budgetRef = firestore.collection("households").document(hid).collection("budgets")
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                runCatching {
                    dao.localWallets().forEach { w ->
                        val docId = "${userId}_${w.id}"
                        walletRef.document(docId).set(mapOf("id" to w.id, "name" to w.name, "owner" to w.owner, "openingBalance" to w.openingBalance, "kind" to w.kind, "createdBy" to userId, "updatedBy" to userId, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()), com.google.firebase.firestore.SetOptions.merge()).await()
                        dao.setWalletCloudId(w.id, docId)
                    }
                    dao.localBudgets().forEach { b ->
                        val docId = "budget_" + java.util.UUID.nameUUIDFromBytes(b.category.trim().lowercase().toByteArray()).toString()
                        budgetRef.document(docId).set(mapOf("category" to b.category, "limitAmount" to b.limitAmount, "createdBy" to userId, "updatedBy" to userId, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()), com.google.firebase.firestore.SetOptions.merge()).await()
                        dao.setBudgetCloudId(b.category, docId)
                    }
                }.onFailure { syncStatus = "Gagal mengirim dompet/anggaran: ${it.localizedMessage}" }
            }
            walletListener?.remove()
            walletListener = walletRef.addSnapshotListener { snap, err ->
                if (err != null) { syncStatus = "Sinkronisasi dompet gagal: ${err.localizedMessage}"; return@addSnapshotListener }
                val remote = snap?.documents.orEmpty().filter { it.getString("createdBy") != userId }.mapNotNull { d ->
                    val name = d.getString("name") ?: return@mapNotNull null
                    Wallet(id = d.id, name = name, owner = d.getString("owner") ?: "Bersama", openingBalance = d.getLong("openingBalance") ?: 0L, kind = d.getString("kind") ?: "Pribadi", cloudDocId = d.id)
                }
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { runCatching { dao.clearCloudWallets(); if (remote.isNotEmpty()) remote.forEach { dao.saveWallet(it) }; withContext(Dispatchers.Main) { refresh() } } }
            }
            budgetListener?.remove()
            budgetListener = budgetRef.addSnapshotListener { snap, err ->
                if (err != null) { syncStatus = "Sinkronisasi anggaran gagal: ${err.localizedMessage}"; return@addSnapshotListener }
                val remote = snap?.documents.orEmpty().mapNotNull { d ->
                    val category = d.getString("category") ?: return@mapNotNull null
                    Budget(category = category, limitAmount = d.getLong("limitAmount") ?: 0L, cloudDocId = d.id)
                }
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { runCatching { dao.clearCloudBudgets(); if (remote.isNotEmpty()) dao.insertBudgets(remote); withContext(Dispatchers.Main) { refresh() } } }
            }
            transactionListener?.remove()
            transactionListener = txRef.addSnapshotListener { snapshot, error ->
                if (error != null) { syncStatus = "Sinkronisasi gagal: ${error.localizedMessage}"; return@addSnapshotListener }
                val remote = snapshot?.documents.orEmpty().filter { it.getString("createdBy") != userId }.mapNotNull { d ->
                    val amount = d.getLong("amount") ?: return@mapNotNull null
                    FinanceTransaction(
                        id = -((java.util.UUID.nameUUIDFromBytes(d.id.toByteArray()).mostSignificantBits and Long.MAX_VALUE).let { if (it == 0L) 1L else it }),
                        title = d.getString("title") ?: "Transaksi",
                        amount = amount,
                        type = d.getString("type") ?: "Pengeluaran",
                        category = d.getString("category") ?: "Lainnya",
                        date = d.getLong("date") ?: System.currentTimeMillis(),
                        note = d.getString("note") ?: "",
                        cloudDocId = d.id
                    )
                }
                kotlinx.coroutines.CoroutineScope(Dispatchers.Main).launch {
                    runCatching {
                        dao.clearCloudTransactions()
                        if (remote.isNotEmpty()) dao.insertTransactions(remote)
                        refresh()
                    }.onSuccess { syncStatus = "Tersinkron • ${remote.size} transaksi pasangan" }
                     .onFailure { syncStatus = "Gagal memperbarui data lokal: ${it.localizedMessage}" }
                }
            }
        }
        onDispose { householdListener?.remove(); transactionListener?.remove(); walletListener?.remove(); budgetListener?.remove() }
    }

    val nowMonth = rows.filter { it.date >= monthStart() }
    val income = nowMonth.filter { it.type == "Pemasukan" }.sumOf { it.amount }
    val expense = nowMonth.filter { it.type == "Pengeluaran" }.sumOf { it.amount }
    val balance = rows.sumOf { if (it.type == "Pemasukan") it.amount else -it.amount }

    if (pinEnabled && !unlocked) {
        PinScreen(pin, { pin = it }, { if (it == pin) unlocked = true })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(36.dp).background(teal, RoundedCornerShape(11.dp)), contentAlignment=Alignment.Center) { Icon(painterResource(id = R.drawable.ic_uangsi_family), null, tint=Color.Unspecified, modifier=Modifier.size(27.dp)) }; Column(Modifier.padding(start=10.dp)) { Text("Uang SI", fontWeight = FontWeight.ExtraBold, color=navy); Text("Keuangan rumah tangga", fontSize = 11.sp, color = muted) } } },
                actions = { IconButton(onClick = { com.google.firebase.auth.FirebaseAuth.getInstance().signOut() }) { Icon(Icons.Default.Logout, "Keluar") }; IconButton(onClick = { showForm = true; edit = null }) { Icon(Icons.Default.Add, "Tambah") } }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = navy,
                contentColor = Color.White,
                tonalElevation = 10.dp
            ) {
                listOf("Beranda","Transaksi","Dompet","Chat","Keluarga","Pembagian","Anggaran","Laporan","Pengaturan").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Icon(
                                when(item) {
                                    "Beranda" -> Icons.Filled.Home
                                    "Transaksi" -> Icons.Filled.ReceiptLong
                                    "Pembagian" -> Icons.Filled.PieChart
                                    "Dompet" -> Icons.Filled.AccountBalanceWallet
                                    "Keluarga" -> Icons.Filled.FamilyRestroom
                                    "Chat" -> Icons.Filled.ChatBubble
                                    "Anggaran" -> Icons.Filled.Savings
                                    "Laporan" -> Icons.Filled.BarChart
                                    else -> Icons.Filled.Settings
                                }, item
                            )
                        },
                        label = { Text(item, maxLines = 1, fontSize = 9.sp) },
                        alwaysShowLabel = true,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color(0xFF35E0CF),
                            indicatorColor = Color(0xFF087F83),
                            unselectedIconColor = Color(0xFFD4E2EF),
                            unselectedTextColor = Color(0xFFB9C9D9)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (page == "Beranda" || page == "Transaksi") FloatingActionButton(onClick = { edit = null; showForm = true }) { Icon(Icons.Default.Add, "Tambah transaksi") }
        }
    ) { pad ->
        when(page) {
            "Beranda" -> Column(Modifier.padding(pad)) {
                Text("☁ $syncStatus", modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 8.dp), color = teal, fontSize = 11.sp)
                HomePage(Modifier.weight(1f), balance, income, expense, rows.take(5), { edit = it; showForm = true })
            }
            "Transaksi" -> Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
                OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Cari transaksi") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                Row(Modifier.padding(vertical=8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Semua","Pemasukan","Pengeluaran").forEach { FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it) }) }
                }
                TransactionList(rows.filter { (filter == "Semua" || it.type == filter) && (it.title.contains(search,true) || it.category.contains(search,true)) }, { edit = it; showForm = true }, { t -> scope.launch {
                    val hid = com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("users").document(userId).get().await().getString("householdId")
                    val cloudOk = if (hid != null) {
                        val docId = t.cloudDocId ?: "${userId}_${t.id}"
                        runCatching { com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("households").document(hid).collection("transactions").document(docId).delete().await() }.isSuccess
                    } else true
                    if (cloudOk) { dao.delete(t); refresh() }
                    else syncStatus = "Penghapusan belum tersinkron. Data lokal dipertahankan; coba lagi saat internet tersedia."
                } })
            }
            "Dompet" -> WalletPage(wallets, { w -> scope.launch {
                dao.saveWallet(w)
                runCatching {
                    val fs = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    val hid = fs.collection("users").document(userId).get().await().getString("householdId")
                    if (hid != null) {
                        val docId = w.cloudDocId ?: "${userId}_${w.id}"
                        fs.collection("households").document(hid).collection("wallets").document(docId).set(mapOf("id" to w.id, "name" to w.name, "owner" to w.owner, "openingBalance" to w.openingBalance, "kind" to w.kind, "createdBy" to userId, "updatedBy" to userId, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()), com.google.firebase.firestore.SetOptions.merge()).await()
                        dao.setWalletCloudId(w.id, docId)
                    }
                }.onFailure { syncStatus = "Dompet tersimpan lokal; cloud gagal: ${it.localizedMessage}" }
                refresh()
            } }, { w -> scope.launch {
                val cloudOk = runCatching { val fs = com.google.firebase.firestore.FirebaseFirestore.getInstance(); val hid = fs.collection("users").document(userId).get().await().getString("householdId"); if (hid != null) fs.collection("households").document(hid).collection("wallets").document(w.cloudDocId ?: "${userId}_${w.id}").delete().await() }.isSuccess
                if (cloudOk) { dao.deleteWallet(w); refresh() } else syncStatus = "Penghapusan dompet belum tersinkron; data lokal dipertahankan."
            } }, Modifier.padding(pad))
            "Keluarga" -> HouseholdPage(userId, Modifier.padding(pad))
            "Chat" -> CoupleChatPage(userId, Modifier.padding(pad))
            "Pembagian" -> AllocationPage(rows, userId, Modifier.padding(pad))
            "Anggaran" -> BudgetPage(budgets, rows, { b -> scope.launch {
                dao.saveBudget(b)
                runCatching {
                    val fs = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    val hid = fs.collection("users").document(userId).get().await().getString("householdId")
                    if (hid != null) {
                        val docId = b.cloudDocId ?: ("budget_" + java.util.UUID.nameUUIDFromBytes(b.category.trim().lowercase().toByteArray()).toString())
                        val payload = mutableMapOf<String, Any>("category" to b.category, "limitAmount" to b.limitAmount, "updatedBy" to userId, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
                        if (b.cloudDocId == null) payload["createdBy"] = userId
                        fs.collection("households").document(hid).collection("budgets").document(docId).set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
                        dao.setBudgetCloudId(b.category, docId)
                    }
                }.onFailure { syncStatus = "Anggaran tersimpan lokal; cloud gagal: ${it.localizedMessage}" }
                refresh()
            } }, Modifier.padding(pad))
            "Laporan" -> ReportPage(rows, Modifier.padding(pad))
            else -> SettingsPage(pinEnabled, { pinEnabled = it; if (!it) unlocked = false }, { pin = it; pinEnabled = true; unlocked = true }, {
                scope.launch {
                    runCatching {
                        val fs = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        val hid = fs.collection("users").document(userId).get().await().getString("householdId")
                        // Hapus dokumen cloud yang dibuat akun ini saja. Data pasangan tidak disentuh.
                        if (!hid.isNullOrBlank()) {
                            val household = fs.collection("households").document(hid)
                            suspend fun deleteOwned(collectionName: String) {
                                val ref = household.collection(collectionName)
                                val owned = ref.whereEqualTo("createdBy", userId).get().await()
                                owned.documents.chunked(450).forEach { group ->
                                    val batch = fs.batch()
                                    group.forEach { doc -> batch.delete(doc.reference) }
                                    batch.commit().await()
                                }
                            }
                            deleteOwned("transactions")
                            deleteOwned("wallets")
                            deleteOwned("budgets")
                        }
                        // Hapus seluruh salinan lokal pada database akun yang sedang digunakan.
                        // Tidak memakai FinanceDb.get(context), karena aplikasi memakai nama DB per UID.
                        dao.clearTransactions()
                        dao.clearBudgets()
                        dao.clearAllWallets()
                        refresh()
                    }.onSuccess {
                        backupMessage = "Data lokal akun ini dan data cloud yang dibuat akun ini berhasil dihapus. Data milik pasangan tetap tersimpan dan dapat muncul kembali karena rumah tangga digunakan bersama."
                    }.onFailure { error ->
                        backupMessage = "Penghapusan belum selesai: ${error.message ?: "kesalahan tidak diketahui"}. Data lokal dipertahankan agar tidak hilang sebelum penghapusan cloud terkonfirmasi. Periksa koneksi lalu coba lagi."
                    }
                }
            }, rows, { exportLauncher.launch("UangSI_backup.json") }, { importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }, Modifier.padding(pad))
        }
    }
    pendingRestore?.let { backup ->
        AlertDialog(onDismissRequest = { pendingRestore = null },
            title = { Text("Pulihkan backup?") },
            text = { Text("Backup berisi ${backup.transactions.size} transaksi dan ${backup.budgets.size} anggaran. Pemulihan akan mengganti seluruh data yang ada saat ini. Pastikan Anda sudah memiliki salinan data terbaru.") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    runCatching {
                        FinanceDb.get(context).withTransaction {
                            dao.clearTransactions(); dao.clearBudgets()
                            if (backup.transactions.isNotEmpty()) dao.insertTransactions(backup.transactions)
                            if (backup.budgets.isNotEmpty()) dao.insertBudgets(backup.budgets)
                        }
                        refresh()
                    }.onSuccess { backupMessage = "Data berhasil dipulihkan." }
                     .onFailure { backupMessage = "Pemulihan gagal: ${it.message ?: "kesalahan tidak diketahui"}" }
                    pendingRestore = null
                }
            }) { Text("Pulihkan", color = red) } },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Batal") } })
    }
    backupMessage?.let { message ->
        AlertDialog(onDismissRequest = { backupMessage = null }, title = { Text("Backup & Restore") },
            text = { Text(message) }, confirmButton = { TextButton(onClick = { backupMessage = null }) { Text("OK") } })
    }
    if (showForm) TransactionDialog(edit, onDismiss = { showForm = false }, onSave = { t ->
        scope.launch {
            val localId = if (t.id == 0L) dao.insert(t) else { dao.update(t); t.id }
            val saved = dao.allTransactions().firstOrNull { it.id == localId }
            val fs = com.google.firebase.firestore.FirebaseFirestore.getInstance()
            val hid = runCatching { fs.collection("users").document(userId).get().await().getString("householdId") }.getOrNull()
            if (hid != null && saved != null) {
                val docId = saved.cloudDocId ?: "${userId}_${saved.id}"
                val payload = mutableMapOf<String, Any>(
                    "title" to saved.title, "amount" to saved.amount, "type" to saved.type,
                    "category" to saved.category, "date" to saved.date, "note" to saved.note,
                    "localId" to saved.id, "updatedBy" to userId,
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                if (saved.cloudDocId == null) payload["createdBy"] = userId
                runCatching {
                    fs.collection("households").document(hid).collection("transactions").document(docId)
                        .set(payload, com.google.firebase.firestore.SetOptions.merge()).await()
                    dao.setTransactionCloudId(saved.id, docId)
                }.onFailure { syncStatus = "Transaksi tersimpan lokal; sinkronisasi cloud gagal: ${it.localizedMessage}" }
            }
            refresh()
        }
        showForm = false
    })
}

@Composable
fun HouseholdPage(userId: String, modifier: Modifier = Modifier) {
    val db = remember { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    val auth = remember { com.google.firebase.auth.FirebaseAuth.getInstance() }
    var householdId by remember { mutableStateOf("") }
    var householdName by remember { mutableStateOf("") }
    var inviteCode by remember { mutableStateOf("") }
    var joinCode by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Memeriksa keanggotaan...") }
    LaunchedEffect(userId) {
        db.collection("users").document(userId).get()
            .addOnSuccessListener { doc ->
                householdId = doc.getString("householdId") ?: ""
                if (householdId.isNotBlank()) {
                    db.collection("households").document(householdId).get()
                        .addOnSuccessListener { h -> householdName = h.getString("name") ?: "Rumah tangga"; inviteCode = h.getString("inviteCode") ?: ""; message = "Anda sudah tergabung dalam rumah tangga." }
                        .addOnFailureListener { message = it.localizedMessage ?: "Gagal membaca rumah tangga." }
                } else message = "Buat rumah tangga atau gabung menggunakan kode pasangan."
            }
            .addOnFailureListener { message = it.localizedMessage ?: "Gagal memeriksa akun." }
    }
    Column(modifier.fillMaxSize().background(pale).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Rumah tangga", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = navy)
        Text("Hubungkan akun suami dan istri dalam satu ruang keuangan.", color = muted, fontSize = 13.sp)
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (householdId.isBlank()) "Status keanggotaan" else householdName, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = navy)
                Text(message, color = muted, fontSize = 12.sp)
                if (householdId.isNotBlank()) {
                    Text("Kode undangan pasangan", fontWeight = FontWeight.SemiBold, color = navy)
                    Text(inviteCode, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = teal, letterSpacing = 3.sp)
                    Text("Bagikan kode ini kepada pasangan. Jangan bagikan kepada orang lain.", fontSize = 11.sp, color = muted)
                }
            }
        }
        if (householdId.isBlank()) {
            var name by remember { mutableStateOf("") }
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Buat rumah tangga", fontWeight = FontWeight.Bold, color = navy)
                    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nama keluarga, contoh: Keluarga Gilang") }, singleLine = true)
                    Button(onClick = {
                        if (name.isBlank() || busy) return@Button
                        busy = true
                        val hid = java.util.UUID.randomUUID().toString()
                        val code = (100000..999999).random().toString()
                        val batch = db.batch()
                        val household = db.collection("households").document(hid)
                        batch.set(household, mapOf("name" to name.trim(), "ownerId" to userId, "inviteCode" to code, "createdAt" to System.currentTimeMillis()))
                        batch.set(household.collection("members").document(userId), mapOf("uid" to userId, "role" to "owner", "joinedAt" to System.currentTimeMillis()))
                        batch.set(db.collection("invites").document(code), mapOf("householdId" to hid, "active" to true, "createdBy" to userId))
                        batch.set(db.collection("users").document(userId), mapOf("householdId" to hid), com.google.firebase.firestore.SetOptions.merge())
                        batch.commit().addOnSuccessListener { householdId = hid; householdName = name.trim(); inviteCode = code; message = "Rumah tangga berhasil dibuat."; busy = false }
                            .addOnFailureListener { message = it.localizedMessage ?: "Gagal membuat rumah tangga."; busy = false }
                    }, enabled = !busy && name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Memproses..." else "Buat rumah tangga") }
                }
            }
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Gabung dengan kode pasangan", fontWeight = FontWeight.Bold, color = navy)
                    OutlinedTextField(joinCode, { joinCode = it.filter(Char::isDigit).take(6) }, Modifier.fillMaxWidth(), label = { Text("Kode undangan 6 digit") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Button(onClick = {
                        if (joinCode.length != 6 || busy) return@Button
                        busy = true
                        db.collection("invites").document(joinCode).get().addOnSuccessListener { inv ->
                            val hid = inv.getString("householdId")
                            if (inv.getBoolean("active") != true || hid.isNullOrBlank()) { message = "Kode tidak valid atau sudah tidak aktif."; busy = false }
                            else {
                                val batch = db.batch()
                                batch.set(db.collection("households").document(hid).collection("members").document(userId), mapOf("uid" to userId, "role" to "member", "inviteCode" to joinCode, "joinedAt" to System.currentTimeMillis()))
                                batch.set(db.collection("users").document(userId), mapOf("householdId" to hid), com.google.firebase.firestore.SetOptions.merge())
                                batch.commit().addOnSuccessListener {
                                    householdId = hid
                                    db.collection("households").document(hid).get().addOnSuccessListener { h -> householdName = h.getString("name") ?: "Rumah tangga"; inviteCode = h.getString("inviteCode") ?: ""; message = "Berhasil bergabung dengan pasangan."; busy = false }
                                }.addOnFailureListener { message = it.localizedMessage ?: "Gagal bergabung."; busy = false }
                            }
                        }.addOnFailureListener { message = it.localizedMessage ?: "Gagal memeriksa kode."; busy = false }
                    }, enabled = !busy && joinCode.length == 6, modifier = Modifier.fillMaxWidth()) { Text("Gabung rumah tangga") }
                }
            }
        }
        Text("Catatan: tahap ini menyiapkan rumah tangga dan undangan pasangan. Sinkronisasi transaksi/dompet lintas HP akan diaktifkan pada tahap berikutnya.", color = muted, fontSize = 11.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomePage(modifier: Modifier, balance: Long, income: Long, expense: Long, recent: List<FinanceTransaction>, onEdit: (FinanceTransaction)->Unit) {
    val monthName = SimpleDateFormat("MMMM yyyy", Locale("id")).format(Date())
    Column(modifier.fillMaxSize().background(pale)) {
        Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(navy, navyLight))).padding(start=20.dp,end=20.dp,top=18.dp,bottom=26.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
                Column {
                    Text("Halo, keluarga! 👋", color=Color.White, fontSize=21.sp, fontWeight=FontWeight.Bold)
                    Text("Ringkasan keuangan • $monthName", color=Color.White.copy(alpha=.75f), fontSize=12.sp)
                }
                Box(Modifier.size(42.dp).background(Color.White.copy(alpha=.15f), RoundedCornerShape(14.dp)), contentAlignment=Alignment.Center) {
                    Icon(Icons.Default.FamilyRestroom, null, tint=Color.White, modifier=Modifier.size(24.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("TOTAL SALDO TERCATAT", color=Color.White.copy(alpha=.72f), fontSize=11.sp, fontWeight=FontWeight.SemiBold, letterSpacing=1.sp)
            Text(rupiah(balance), color=Color.White, fontSize=30.sp, fontWeight=FontWeight.ExtraBold, modifier=Modifier.padding(top=4.dp))
            Text("Saldo berdasarkan transaksi yang sudah dicatat", color=Color.White.copy(alpha=.7f), fontSize=11.sp, modifier=Modifier.padding(top=4.dp))
        }
        Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
            Row(Modifier.offset(y=(-16).dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Card(Modifier.weight(1f), shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(3.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.TrendingUp, null, tint=green, modifier=Modifier.size(18.dp)); Text("  Pemasukan", color=muted, fontSize=12.sp) }
                        Text(rupiah(income), fontSize=16.sp, fontWeight=FontWeight.Bold, color=green, modifier=Modifier.padding(top=8.dp))
                        Text("Bulan ini", fontSize=10.sp, color=muted)
                    }
                }
                Card(Modifier.weight(1f), shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(3.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.TrendingDown, null, tint=red, modifier=Modifier.size(18.dp)); Text("  Pengeluaran", color=muted, fontSize=12.sp) }
                        Text(rupiah(expense), fontSize=16.sp, fontWeight=FontWeight.Bold, color=red, modifier=Modifier.padding(top=8.dp))
                        Text("Bulan ini", fontSize=10.sp, color=muted)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top=2.dp,bottom=10.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("Transaksi terbaru", fontWeight=FontWeight.Bold, fontSize=18.sp, color=navy)
                Text("Terakhir dicatat", fontSize=11.sp, color=muted)
            }
            if (recent.isEmpty()) {
                Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ReceiptLong, null, tint=teal, modifier=Modifier.size(38.dp))
                        Text("Belum ada transaksi", fontWeight=FontWeight.Bold, color=navy, modifier=Modifier.padding(top=10.dp))
                        Text("Tekan tombol + untuk mencatat pemasukan atau pengeluaran pertama.", color=muted, fontSize=12.sp)
                    }
                }
            } else TransactionList(recent, onEdit, {})
        }
    }
}

@Composable
fun TransactionList(rows: List<FinanceTransaction>, onEdit: (FinanceTransaction)->Unit, onDelete: (FinanceTransaction)->Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(rows, key = { it.id }) { t ->
            Card(Modifier.fillMaxWidth().clickable { onEdit(t) }, colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(if(t.type=="Pemasukan") Color(0xFFE4F5EC) else Color(0xFFFFEAEA), RoundedCornerShape(13.dp)), contentAlignment=Alignment.Center) {
                        Icon(if(t.type=="Pemasukan") Icons.Default.TrendingUp else Icons.Default.TrendingDown, null, tint=if(t.type=="Pemasukan") green else red)
                    }
                    Column(Modifier.weight(1f).padding(start=12.dp)) {
                        Text(t.title, fontWeight=FontWeight.SemiBold)
                        Text("${t.category} • ${SimpleDateFormat("dd MMM yyyy", Locale("id")).format(Date(t.date))}", color=Color.Gray, fontSize=12.sp)
                    }
                    Column(horizontalAlignment=Alignment.End) {
                        Text((if(t.type=="Pemasukan") "+" else "-") + rupiah(t.amount), color=if(t.type=="Pemasukan") green else red, fontWeight=FontWeight.Bold)
                        if (onDelete !== {}) { /* delete action available in transaction editor */ }
                    }
                }
            }
        }
        if(rows.isEmpty()) item { Text("Belum ada transaksi. Tekan tombol + untuk mulai mencatat.", color=Color.Gray, modifier=Modifier.padding(20.dp)) }
    }
}

@Composable
fun TransactionDialog(existing: FinanceTransaction?, onDismiss:()->Unit, onSave:(FinanceTransaction)->Unit) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.toString() ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "Pengeluaran") }
    var category by remember { mutableStateOf(existing?.category ?: "Makan") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    val categories = if(type=="Pemasukan") listOf("Gaji","Bonus","Usaha","Investasi","Lainnya") else listOf("Makan","Transportasi","Belanja","Tagihan","Kesehatan","Hiburan","Pendidikan","Rumah","Lainnya")
    AlertDialog(onDismissRequest=onDismiss, title={Text(if(existing==null) "Tambah transaksi" else "Edit transaksi")}, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FilterChip(type=="Pemasukan",{type="Pemasukan";category="Gaji"},{Text("Pemasukan")}); FilterChip(type=="Pengeluaran",{type="Pengeluaran";category="Makan"},{Text("Pengeluaran")}) }
            OutlinedTextField(title,{title=it},label={Text("Nama transaksi")},singleLine=true)
            OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Nominal (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
            Text("Kategori", fontWeight=FontWeight.SemiBold)
            Column { categories.chunked(3).forEach { group -> Row { group.forEach { c -> FilterChip(category==c,{category=c},{Text(c)}, modifier=Modifier.padding(end=4.dp)) } } } }
            OutlinedTextField(note,{note=it},label={Text("Catatan (opsional)")})
        }
    }, confirmButton={ TextButton(onClick={ val n=amount.toLongOrNull() ?: 0L; if(title.isNotBlank() && n>0) onSave(FinanceTransaction(existing?.id ?: 0,title,n,type,category,existing?.date ?: System.currentTimeMillis(),note)) }) { Text("Simpan") } }, dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})
}

@Composable
fun WalletPage(wallets: List<Wallet>, onSave: (Wallet) -> Unit, onDelete: (Wallet) -> Unit, modifier: Modifier = Modifier) {
    var name by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("Suami") }
    var kind by remember { mutableStateOf("Pribadi") }
    var opening by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    val total = wallets.sumOf { it.openingBalance }
    Column(modifier.fillMaxSize().background(pale).padding(16.dp)) {
        Text("Dompet keluarga", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = navy)
        Text("Kelola dompet pribadi suami, istri, dan bersama.", color = muted, fontSize = 13.sp)
        Card(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 14.dp), colors = CardDefaults.cardColors(containerColor = navy), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("TOTAL SALDO AWAL DOMPET", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                Text(rupiah(total), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("Saldo awal yang dicatat manual", color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
            }
        }
        Button(onClick = { showForm = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("  Tambah dompet") }
        if (wallets.isEmpty()) Text("Belum ada dompet. Tambahkan dompet Suami, Istri, atau Bersama.", color = muted, modifier = Modifier.padding(top = 18.dp))
        LazyColumn(Modifier.weight(1f).padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(wallets, key = { it.id }) { w ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(17.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(0xFFE3F4F2), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountBalanceWallet, null, tint = teal) }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(w.name, fontWeight = FontWeight.Bold, color = navy)
                            Text("${w.owner} • ${w.kind}", color = muted, fontSize = 12.sp)
                            Text(rupiah(w.openingBalance), color = teal, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { onDelete(w) }) { Icon(Icons.Default.DeleteOutline, "Hapus dompet", tint = red) }
                    }
                }
            }
        }
        Text("Dompet tersimpan di rumah tangga dan disinkronkan ke perangkat pasangan saat terhubung internet.", color = muted, fontSize = 10.sp)
    }
    if (showForm) AlertDialog(onDismissRequest = { showForm = false }, title = { Text("Tambah dompet") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nama dompet") }, singleLine = true)
            Text("Pemilik", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("Suami", "Istri", "Bersama").forEach { FilterChip(selected = owner == it, onClick = { owner = it }, label = { Text(it) }) } }
            Text("Jenis", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("Pribadi", "Rumah tangga", "Tabungan").forEach { FilterChip(selected = kind == it, onClick = { kind = it }, label = { Text(it) }) } }
            OutlinedTextField(opening, { opening = it.filter(Char::isDigit) }, label = { Text("Saldo awal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = {
        val amount = opening.toLongOrNull() ?: 0L
        if (name.isNotBlank() && amount >= 0L) { onSave(Wallet(java.util.UUID.randomUUID().toString(), name.trim(), owner, amount, kind)); name = ""; opening = ""; owner = "Suami"; kind = "Pribadi"; showForm = false }
    }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } })
}

@Composable
fun AllocationPage(rows: List<FinanceTransaction>, userId: String, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember(userId) { context.getSharedPreferences("uangsi_allocation_$userId", Context.MODE_PRIVATE) }
    val labels = listOf("Kebutuhan rumah tangga", "Tabungan masa depan", "Dana darurat", "Cicilan dan kewajiban", "Uang pribadi suami", "Uang pribadi istri")
    val defaults = listOf(50, 20, 10, 10, 5, 5)
    var percentages by remember(userId) { mutableStateOf(labels.indices.map { prefs.getInt("p_$it", defaults[it]).toString() }) }
    var message by remember { mutableStateOf("") }
    val monthIncome = rows.filter { it.type == "Pemasukan" && it.date >= monthStart() }.sumOf { it.amount }
    val totalPercent = percentages.sumOf { it.toIntOrNull() ?: 0 }
    Column(modifier.fillMaxSize().background(pale).padding(16.dp)) {
        Text("Pembagian gaji", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = navy)
        Text("Atur alokasi pemasukan keluarga sesuai kesepakatan bersama.", color = muted, fontSize = 13.sp)
        Card(Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = navy)) {
            Column(Modifier.padding(18.dp)) {
                Text("TOTAL PEMASUKAN BULAN INI", color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                Text(rupiah(monthIncome), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("Berdasarkan transaksi pemasukan yang sudah dicatat", color = Color.White.copy(alpha = .72f), fontSize = 11.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Pos alokasi", fontWeight = FontWeight.Bold, color = navy, fontSize = 17.sp)
            Text("Total $totalPercent%", color = if (totalPercent == 100) green else red, fontWeight = FontWeight.Bold)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
            items(labels.size) { index ->
                val pct = percentages[index].toIntOrNull()?.coerceIn(0, 100) ?: 0
                val amount = monthIncome * pct / 100
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(labels[index], Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = navy, fontSize = 13.sp)
                            OutlinedTextField(value = percentages[index], onValueChange = { raw ->
                                percentages = percentages.toMutableList().also { it[index] = raw.filter(Char::isDigit).take(3) }
                            }, modifier = Modifier.width(82.dp), suffix = { Text("%") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        }
                        Text(rupiah(amount), color = teal, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
                        LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp))
                    }
                }
            }
        }
        if (message.isNotBlank()) Text(message, color = if (totalPercent == 100) green else red, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        Button(onClick = {
            if (percentages.all { (it.toIntOrNull() ?: -1) in 0..100 } && totalPercent == 100) {
                percentages.forEachIndexed { i, value -> prefs.edit().putInt("p_$i", value.toInt()).apply() }
                message = "Pembagian berhasil disimpan di perangkat ini."
            } else message = "Pastikan setiap persentase 0–100 dan total tepat 100%."
        }, modifier = Modifier.fillMaxWidth().height(50.dp), enabled = totalPercent == 100 && percentages.all { (it.toIntOrNull() ?: -1) in 0..100 }) { Text("Simpan pembagian", fontWeight = FontWeight.Bold) }
        Text("Catatan: ini adalah rencana alokasi, bukan pemindahan uang antar rekening. Pengaturan saat ini tersimpan di perangkat untuk akun ini.", color = muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun BudgetPage(budgets: List<Budget>, rows: List<FinanceTransaction>, onSave:(Budget)->Unit, modifier:Modifier=Modifier) {
    var category by remember { mutableStateOf("Makan") }
    var limit by remember { mutableStateOf("") }
    val spent = rows.filter { it.type=="Pengeluaran" && it.date>=monthStart() }.groupBy { it.category }.mapValues { it.value.sumOf { t -> t.amount } }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Anggaran bulanan", fontSize=21.sp, fontWeight=FontWeight.Bold)
        Text("Atur batas pengeluaran untuk setiap kategori.", color=Color.Gray)
        OutlinedTextField(category,{category=it},label={Text("Kategori")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(limit,{limit=it.filter(Char::isDigit)},label={Text("Batas anggaran (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        Button(onClick={ limit.toLongOrNull()?.takeIf{it>0}?.let{onSave(Budget(category.trim(),it));limit=""} },modifier=Modifier.padding(vertical=8.dp)) { Text("Simpan anggaran") }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(budgets) { b ->
                val used=spent[b.category] ?: 0L
                val progress=(used.toFloat()/b.limitAmount.toFloat()).coerceIn(0f,1f)
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(b.category,fontWeight=FontWeight.Bold); Text("${(progress*100).toInt()}%") }
                    LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp))
                    Text("${rupiah(used)} dari ${rupiah(b.limitAmount)}",fontSize=12.sp,color=Color.Gray)
                } }
            }
        }
    }
}

@Composable
fun ReportPage(rows: List<FinanceTransaction>, modifier:Modifier=Modifier) {
    val monthly=rows.filter { it.date>=monthStart() }
    val inc=monthly.filter{it.type=="Pemasukan"}.sumOf{it.amount}
    val exp=monthly.filter{it.type=="Pengeluaran"}.sumOf{it.amount}
    val byCat=monthly.filter{it.type=="Pengeluaran"}.groupBy{it.category}.mapValues{it.value.sumOf{t->t.amount}}.toList().sortedByDescending{it.second}
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Laporan bulan ini",fontSize=21.sp,fontWeight=FontWeight.Bold)
        SummaryLine("Total pemasukan",inc,green); SummaryLine("Total pengeluaran",exp,red); SummaryLine("Selisih",inc-exp,navy)
        Text("Pengeluaran per kategori",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(top=18.dp,bottom=8.dp))
        byCat.forEach { (cat,amt) ->
            Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween) { Text(cat); Text(rupiah(amt),fontWeight=FontWeight.SemiBold) }
            LinearProgressIndicator(progress={if(exp==0L) 0f else amt.toFloat()/exp},modifier=Modifier.fillMaxWidth())
        }
        if(byCat.isEmpty()) Text("Belum ada data pengeluaran bulan ini.",color=Color.Gray)
    }
}
@Composable fun SummaryLine(label:String, value:Long, color:Color) {
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) { Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(label); Text(rupiah(value),fontWeight=FontWeight.Bold,color=color) } }
}

private fun validateBackup(backup: FinanceBackup) {
    require(backup.format == "KeuanganKuBackup") { "File bukan backup KeuanganKu." }
    require(backup.version == 1) { "Versi backup tidak didukung." }
    require(backup.transactions.size <= 100_000) { "Jumlah transaksi terlalu besar." }
    require(backup.budgets.size <= 10_000) { "Jumlah anggaran terlalu besar." }
    require(backup.transactions.all { it.id >= 0L && it.title.isNotBlank() && it.amount > 0L && it.type in setOf("Pemasukan", "Pengeluaran") && it.category.isNotBlank() && it.date > 0L }) { "Data transaksi tidak valid." }
    require(backup.transactions.map { it.id }.distinct().size == backup.transactions.size) { "ID transaksi duplikat." }
    require(backup.budgets.all { it.category.isNotBlank() && it.limitAmount > 0L }) { "Data anggaran tidak valid." }
    require(backup.budgets.map { it.category }.distinct().size == backup.budgets.size) { "Kategori anggaran duplikat." }
}

@Composable
fun SettingsPage(pinEnabled:Boolean,onPinToggle:(Boolean)->Unit,onSetPin:(String)->Unit,onClear:()->Unit,rows:List<FinanceTransaction>,onExport:()->Unit,onImport:()->Unit,modifier:Modifier=Modifier) {
    var newPin by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Pengaturan",fontSize=22.sp,fontWeight=FontWeight.Bold)
        Text("Keamanan",fontWeight=FontWeight.Bold)
        Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Kunci PIN"); Text("Minta PIN saat membuka aplikasi",fontSize=12.sp,color=Color.Gray) }; Switch(pinEnabled,{onPinToggle(it)}) }
        OutlinedTextField(newPin,{newPin=it.filter(Char::isDigit).take(6)},label={Text("Atur PIN 4–6 angka")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        Button(onClick={if(newPin.length in 4..6) onSetPin(newPin)},enabled=newPin.length in 4..6){Text("Simpan PIN")}
        Divider()
        Text("Data",fontWeight=FontWeight.Bold)
        Text("Data disimpan secara offline di penyimpanan aplikasi. Total ${rows.size} transaksi.")
        OutlinedButton(onClick=onExport, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Cadangkan data (JSON)") }
        OutlinedButton(onClick=onImport, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Pulihkan dari file backup") }
        Text("Backup menyimpan transaksi dan anggaran. Penghapusan menghapus data lokal akun ini serta data cloud yang dibuat akun ini; data pasangan tidak dihapus.",fontSize=12.sp,color=Color.Gray)
        OutlinedButton(onClick={confirmClear=true},colors=ButtonDefaults.outlinedButtonColors(contentColor=red)){Text("Hapus data akun ini")}
    }
    if(confirmClear) AlertDialog(onDismissRequest={confirmClear=false},title={Text("Hapus semua data?")},text={Text("Transaksi, dompet, dan anggaran lokal akan dihapus. Data cloud yang dibuat akun ini juga dihapus jika terhubung internet. Data milik pasangan tidak ikut dihapus. Pastikan sudah membuat backup.")},confirmButton={TextButton(onClick={onClear;confirmClear=false}){Text("Hapus",color=red)}},dismissButton={TextButton(onClick={confirmClear=false}){Text("Batal")}})
}

@Composable
fun PinScreen(pin:String,onPinChange:(String)->Unit,onUnlock:(String)->Unit) {
    var entered by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(pale).padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.Lock,null,tint=navy,modifier=Modifier.size(48.dp))
        Text("Uang SI terkunci",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(12.dp))
        OutlinedTextField(entered,{entered=it.filter(Char::isDigit).take(6)},label={Text("Masukkan PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        Button(onClick={onUnlock(entered)},modifier=Modifier.padding(12.dp)){Text("Buka")}
        Text("PIN awal belum tersinkron jika aplikasi baru dipasang.",fontSize=11.sp,color=Color.Gray)
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoupleChatPage(userId: String, modifier: Modifier = Modifier) {
    val db = remember { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()
    var householdId by remember { mutableStateOf<String?>(null) }
    var messages by remember { mutableStateOf(emptyList<Map<String, Any>>()) }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Menghubungkan chat…") }
    var sending by remember { mutableStateOf(false) }

    LaunchedEffect(userId) {
        runCatching { db.collection("users").document(userId).get().await().getString("householdId") }
            .onSuccess { hid -> householdId = hid; status = if (hid.isNullOrBlank()) "Buat atau gabung rumah tangga terlebih dahulu di menu Keluarga." else "Chat pribadi rumah tangga" }
            .onFailure { status = "Gagal memeriksa rumah tangga: ${it.localizedMessage}" }
    }

    DisposableEffect(householdId, userId) {
        val hid = householdId
        if (hid.isNullOrBlank()) return@DisposableEffect onDispose { }
        val registration = db.collection("households").document(hid).collection("messages")
            .orderBy("clientTime")
            .addSnapshotListener { snapshot, error ->
                if (error != null) { status = "Chat tidak dapat dimuat: ${error.localizedMessage}" }
                else if (snapshot != null) {
                    messages = snapshot.documents.mapNotNull { doc -> doc.data?.plus("messageId" to doc.id) }
                    status = "Terhubung • ${messages.size} pesan"
                    snapshot.documents.filter { doc ->
                        val sender = doc.getString("senderId")
                        val readBy = doc.get("readBy") as? List<*>
                        sender != userId && (readBy?.contains(userId) != true)
                    }.forEach { doc ->
                        doc.reference.update("readBy", com.google.firebase.firestore.FieldValue.arrayUnion(userId))
                    }
                }
            }
        onDispose { registration.remove() }
    }

    Column(modifier.fillMaxSize().background(pale).padding(14.dp)) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = navy)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(teal, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.FamilyRestroom, null, tint = Color.White)
                }
                Column(Modifier.padding(start = 12.dp)) {
                    Text("Chat Pasangan", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(status, color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
                }
            }
        }
        if (householdId.isNullOrBlank()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(status, color = muted)
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), reverseLayout = false, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it["messageId"].toString() }) { message ->
                    val mine = message["senderId"] == userId
                    val body = message["text"] as? String ?: ""
                    val time = (message["clientTime"] as? Number)?.toLong() ?: 0L
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 300.dp).background(if (mine) Color(0xFFDDF7F1) else Color.White, RoundedCornerShape(16.dp)).padding(horizontal = 13.dp, vertical = 9.dp)) {
                            if (!mine) Text("Pasangan", color = teal, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(body, color = navy, fontSize = 14.sp)
                            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (time > 0) SimpleDateFormat("HH:mm", Locale("id")).format(Date(time)) else "", color = muted, fontSize = 9.sp)
                                if (mine) {
                                    val read = (message["readBy"] as? List<*>)?.any { it != userId } == true
                                    Text(if (read) "  ✓✓" else "  ✓", color = teal, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
                if (messages.isEmpty()) item { Text("Belum ada pesan. Mulai percakapan dengan pasanganmu 💚", color = muted, modifier = Modifier.fillMaxWidth().padding(20.dp)) }
            }
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(24.dp)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { if (it.length <= 4000) input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Tulis pesan…") }, maxLines = 4)
                IconButton(enabled = input.isNotBlank() && !sending, onClick = {
                    val hid = householdId ?: return@IconButton
                    val text = input.trim()
                    if (text.isNotEmpty()) scope.launch {
                        sending = true
                        runCatching {
                            val now = System.currentTimeMillis()
                            db.collection("households").document(hid).collection("messages").add(
                                mapOf("senderId" to userId, "text" to text, "clientTime" to now,
                                    "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
                                    "readBy" to listOf(userId))
                            ).await()
                            input = ""
                        }.onFailure { status = "Pesan belum terkirim: ${it.localizedMessage}" }
                        sending = false
                    }
                }) { Icon(Icons.Default.Send, contentDescription = "Kirim", tint = teal) }
            }
        }
    }
}
