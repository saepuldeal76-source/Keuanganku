# KeuanganKu 2.0 — Android Studio + Kotlin

Aplikasi pencatatan keuangan pribadi berbahasa Indonesia dan dapat digunakan secara offline.

## Fitur yang tersedia
- Catat pemasukan dan pengeluaran, kategori, tanggal otomatis, serta catatan.
- Ubah transaksi dengan mengetuk item transaksi.
- Cari dan filter transaksi.
- Ringkasan saldo, pemasukan, dan pengeluaran bulan berjalan.
- Anggaran per kategori dan indikator pemakaian.
- Laporan pengeluaran per kategori.
- Penyimpanan lokal Room (offline).
- Pengaturan PIN dasar (belum menjadi pengamanan kuat).
- **Backup data ke file JSON** melalui pemilih lokasi Android.
- **Restore backup JSON** dengan validasi format dan konfirmasi sebelum mengganti data.
- Restore dijalankan dalam satu transaksi database (atomik), sehingga perubahan tidak diterapkan setengah jalan jika terjadi kegagalan.

## Cara membuka
1. Ekstrak ZIP.
2. Buka Android Studio → Open → pilih folder `KeuanganKu`.
3. Gunakan JDK 17 atau lebih baru dan tunggu Gradle Sync.
4. Jalankan pada perangkat Android atau emulator (minimum Android 7.0 / API 24).

## Backup dan pemulihan
1. Buka **Pengaturan** → **Cadangkan data (JSON)**.
2. Pilih lokasi penyimpanan. Simpan file backup di lokasi aman.
3. Untuk pemulihan, pilih **Pulihkan dari file backup**, lalu pilih file JSON KeuanganKu.
4. Periksa jumlah transaksi dan anggaran pada dialog konfirmasi. Tekan **Pulihkan** hanya jika memang ingin mengganti seluruh data lokal.

**Penting:** file JSON berisi rincian keuangan dalam bentuk teks dan tidak dienkripsi. Simpan di tempat pribadi/aman. Restore mengganti semua transaksi dan anggaran yang ada; buat backup terbaru sebelum memulihkan. File yang rusak, versi tidak didukung, atau data yang tidak lolos validasi akan ditolak.

## Status build
Ini adalah **source project**, bukan APK. Belum dilakukan build Gradle atau pengujian pada perangkat dalam lingkungan pembuatan ini. Untuk membuat APK: Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s).

## Catatan pengembangan berikutnya
Fitur berikutnya dalam roadmap: grafik interaktif, target tabungan, pengingat tagihan, PIN persisten yang lebih kuat, dan ekspor laporan Excel/PDF. PIN pada versi ini masih berupa perlindungan antarmuka dasar.
