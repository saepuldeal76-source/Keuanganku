# Uang SI 3.4.1 — Sinkronisasi Keluarga (beta)

Package Android: `id.keuanganku.app`  
Versi: `3.4.1` (versionCode 9)

## Yang tersedia dalam source
- Firebase Authentication email/password.
- Rumah tangga dan undangan pasangan melalui Firestore.
- Sinkronisasi transaksi keluarga (fondasi beta dari 3.4.0).
- Sinkronisasi dompet dan anggaran melalui koleksi `households/{householdId}/wallets` dan `.../budgets`.
- ID dokumen cloud deterministik untuk dompet dan anggaran; dokumen transaksi menggunakan pola `{uid}_{localId}`.
- Migrasi Room versi 3 ke 4 menambahkan `cloudDocId` untuk dompet dan anggaran. Data lokal yang sudah ada dipertahankan.
- Firestore listeners diperbarui untuk memuat data pasangan; data remote ditandai dengan `cloudDocId` agar tidak diunggah ulang sebagai data lokal.
- Penghapusan transaksi/dompet tidak menghapus data lokal bila operasi cloud gagal.
- Workflow GitHub Actions untuk membangun APK debug.

## Batasan beta dan hal yang belum diverifikasi
- Source ini belum dikompilasi atau diuji pada perangkat Android dalam sesi ini. Jangan menganggap build atau sinkronisasi berhasil sebelum workflow dan uji dua perangkat lulus.
- Sinkronisasi offline belum memiliki antrean/tombstone penghapusan yang tahan terhadap perangkat offline lama. Untuk saat ini, lakukan penghapusan ketika kedua perangkat online.
- Konflik edit bersamaan belum memiliki strategi resolusi versi/last-write-wins yang eksplisit.
- Pengaturan pembagian penghasilan masih lokal; backup JSON saat ini belum menyertakan dompet.
- Transaksi memakai skema lokal lama dan ID numerik Room; migrasi konflik ID untuk data lama lintas perangkat masih perlu pengujian lebih luas.
- Undangan masih menggunakan kode pendek dari implementasi sebelumnya; aturan Firestore tidak menyediakan rate limiting. Untuk penggunaan publik, sebaiknya pindah ke kode acak yang lebih panjang dan/atau callable Cloud Function dengan pembatasan percobaan.
- Belum ada koneksi rekening bank/Open Banking.

## Firebase
1. Pastikan Firebase Authentication Email/Password aktif.
2. Pastikan Firestore Database sudah dibuat.
3. Buka Firestore Database > Rules, ganti dengan isi `firestore.rules`, lalu Publish.
4. Pastikan `app/google-services.json` berasal dari project Firebase yang sama dan package-nya `id.keuanganku.app`.
5. Jangan menggunakan aturan publik `allow read, write: if true`.

## Build lewat GitHub dari HP Android
1. Unduh ZIP source ini dan ekstrak.
2. Upload seluruh isi folder `KeuanganKu` ke repository GitHub (termasuk folder tersembunyi `.github`). Jika memakai upload web, pastikan folder `.github/workflows/build-apk.yml` ikut terunggah.
3. Commit perubahan ke branch `main`.
4. Buka tab **Actions**, pilih workflow **Build KeuanganKu APK**, lalu pilih **Run workflow** (atau tunggu workflow berjalan setelah push).
5. Jika sukses, buka hasil run dan unduh artifact APK.
6. Pasang APK di kedua HP setelah membuat backup data masing-masing.

## Uji minimum dua perangkat
1. Pasang versi 3.4.1 pada dua HP dan login dengan dua akun Firebase berbeda.
2. Buat rumah tangga dari HP pertama, lalu gabungkan HP kedua memakai kode undangan.
3. Tambahkan transaksi, dompet, dan anggaran di HP pertama; pastikan muncul di HP kedua.
4. Ubah item yang sudah tersinkron dan periksa hasilnya di perangkat pasangan.
5. Hapus transaksi/dompet ketika kedua HP online dan pastikan item hilang dari keduanya.
6. Uji akun yang bukan anggota rumah tangga: akses dokumen rumah tangga harus ditolak.
7. Uji tanpa internet hanya untuk memastikan data lokal tetap ada; jangan menganggap penghapusan offline tersinkron.

Simpan backup sebelum update. Migrasi Room menambahkan kolom nullable dan tidak dimaksudkan menghapus data lokal.

## Patch 3.4.1.1 — Perbaikan Hapus Data
- Memperbaiki target database saat menghapus data: tindakan sekarang memakai DAO/database akun aktif (`uangsi_<uid>.db`), bukan instance database lain (`keuanganku.db`).
- Tombol penghapusan kini menghapus transaksi, anggaran, dan dompet lokal.
- Jika akun tergabung dalam rumah tangga dan internet tersedia, dokumen Firestore pada `transactions`, `wallets`, dan `budgets` yang memiliki `createdBy` sama dengan UID akun aktif juga dihapus dalam batch maksimal 450 dokumen.
- Data cloud milik pasangan tidak ikut dihapus. Karena data rumah tangga bersifat bersama, data pasangan yang tersisa dapat tetap terlihat atau muncul kembali di perangkat setelah listener Firestore memperbarui tampilan.
- Jika penghapusan cloud gagal, aplikasi tidak meneruskan penghapusan lokal; pesan kegagalan ditampilkan agar data lokal tidak hilang sebelum operasi cloud terkonfirmasi.
- Versi Android dinaikkan menjadi `3.4.1.1` (versionCode 10). Tidak ada migrasi Room baru; struktur database tidak berubah.


## Uang SI 3.4.1.2 — Penyegaran Logo dan Navigasi
- Logo keluarga berbentuk rumah dengan dua anggota keluarga dan aksen hati, sesuai pilihan logo konsep gambar 1 opsi 2.
- Ikon navigasi bawah menggunakan gaya filled modern dengan bilah navy dan aksen tosca, sesuai gambar 2 opsi 4.
- Seluruh delapan tujuan navigasi yang sudah ada tetap dipertahankan.
- Launcher icon Android menggunakan logo keluarga yang sama.

Catatan: source belum dikompilasi atau diuji pada perangkat; validasi melalui GitHub Actions dan perangkat Android tetap diperlukan.
