# Uang SI 3.4.3 — Chat Pasangan (Beta)

Package Android: `id.keuanganku.app`  
Versi: `3.4.3` (versionCode 13)

## Fitur baru
- Menu **Chat** ditambahkan pada navigasi bawah tanpa menghapus menu yang sudah ada.
- Percakapan real-time memakai Firestore pada lokasi `households/{householdId}/messages`.
- Pesan menampilkan pengirim (Saya/Pasangan), jam, dan status dibaca sederhana (✓ / ✓✓).
- Batas isi pesan 4.000 karakter.
- Chat hanya aktif jika akun sudah tergabung dalam rumah tangga.
- Isi pesan hanya dapat dihapus oleh pengirim; pengguna lain hanya dapat memperbarui daftar `readBy` untuk tanda dibaca.
- Seluruh fitur transaksi, dompet, anggaran, keluarga, pembagian, laporan, dan pengaturan dari 3.4.2 dipertahankan.

## Firestore Rules
1. Firebase Console → Firestore Database → Rules.
2. Ganti seluruh isi rules dengan file `firestore.rules` dari paket ini.
3. Tekan **Publish**.
4. Jangan menghapus database atau koleksi yang sudah ada.

Rules membatasi pembacaan chat untuk anggota rumah tangga. Pembuatan pesan mensyaratkan `senderId` sama dengan UID login. Update hanya boleh menambah daftar `readBy`; pengirim dan isi pesan tidak dapat diubah melalui operasi update. Penghapusan hanya diizinkan untuk pengirim pesan.

## Build dari Android melalui GitHub Actions
1. Backup data aplikasi pada kedua perangkat.
2. Ekstrak ZIP.
3. Unggah seluruh isi folder `KeuanganKu` ke repository GitHub, termasuk `.github/workflows` dan `google-services.json`.
4. Commit ke branch `main`.
5. Buka GitHub → Actions → Build KeuanganKu APK → Run workflow.
6. Jika workflow sukses, unduh artifact APK dan pasang pada kedua HP.

## Uji dua perangkat
1. Gunakan dua akun Firebase berbeda yang sudah tergabung pada rumah tangga yang sama.
2. Kirim pesan dari HP pertama; pastikan muncul pada HP kedua.
3. Buka percakapan di HP kedua; periksa tanda dibaca pada HP pertama.
4. Coba kirim pesan panjang, kirim saat offline, lalu sambungkan kembali. Periksa hasilnya dan jangan menganggap antrean offline sudah dijamin.
5. Pastikan akun di luar rumah tangga tidak dapat membaca pesan.
6. Coba hapus pesan sendiri dan pastikan akun lain tidak dapat menghapus pesan tersebut.

## Batasan beta dan keamanan
- Source belum dikompilasi Gradle atau diuji pada dua perangkat dalam sesi ini.
- Notifikasi push saat aplikasi tertutup **belum tersedia**; versi ini menampilkan pesan real-time ketika aplikasi aktif/terhubung.
- Belum ada lampiran foto/file, edit pesan, indikator sedang mengetik, pencarian, atau backup/ekspor chat.
- Tanda dibaca adalah status sederhana per pengguna; belum ada centang terkirim/diterima terpisah.
- Timestamp urutan menggunakan waktu perangkat (`clientTime`), sehingga perbedaan jam antarperangkat dapat memengaruhi urutan. Server timestamp turut disimpan sebagai `createdAt`.
- Konflik pesan dan pengalaman offline perlu diuji sebelum penggunaan rutin.
- Jangan membagikan `google-services.json` ke repositori publik. Jika repository publik, ubah menjadi private.


## Uang SI 3.4.4 Beta
- Badge jumlah pesan chat yang belum dibaca pada menu Chat.
- Pesan pasangan otomatis ditandai terbaca ketika halaman Chat dibuka.
- Pengirim dapat menghapus pesan miliknya sendiri.
- Logo/navigasi modern dan fitur rumah tangga, transaksi, dompet bersama, anggaran tetap dipertahankan.
- Belum ada push notification ketika aplikasi tertutup; FCM dapat menjadi tahap berikutnya.
- Belum diklaim teruji/terkompilasi sampai GitHub Actions berhasil.


## Uang SI 3.5.0
- Perbaikan transaksi dobel saat sinkronisasi antar-HP: listener cloud sekarang mencocokkan transaksi lokal berdasarkan `cloudDocId` dan `localId` milik akun pembuat sebelum membuat baris baru.
- Menghapus pemanggilan `FinanceApp` ganda yang menyebabkan dua instance aplikasi aktif sekaligus.
- Transaksi sekarang memiliki pemilik akun: **Suami**, **Istri**, atau **Bersama**.
- Pilihan akun tersedia saat menambah/mengedit transaksi.
- Daftar transaksi menampilkan pemilik akun dan dapat difilter berdasarkan Suami/Istri/Bersama.
- Field pemilik transaksi ikut disinkronkan ke Firestore.
- Room migration 4 → 5 menambahkan kolom `owner` dengan default `Suami`.


## Uang SI 3.5.1 — Perbaikan transaksi
- Mencegah pengiriman formulir transaksi berulang saat tombol Simpan ditekan beberapa kali.
- Menampilkan label akun Suami, Istri, atau Bersama pada setiap transaksi.
- Menambahkan tombol hapus pada setiap baris transaksi, dengan dialog konfirmasi sebelum penghapusan.
- Penghapusan menghapus dokumen cloud terkait sebelum menghapus data lokal; jika cloud gagal, data lokal dipertahankan.
- Versi ini tetap menggunakan Firebase/Room dan skema database yang sama seperti 3.5.0.

## Versi 3.5.2 — Keluar dari keluarga
- Menu Keluarga menampilkan aksi **Keluar dari keluarga** untuk anggota non-pemilik.
- Aksi meminta konfirmasi, menghapus keanggotaan akun sendiri, dan menghapus referensi `householdId` dari profil pengguna.
- Data rumah tangga dan transaksi bersama tidak dihapus.
- Pemilik rumah tangga belum dapat keluar langsung; kepemilikan harus ditangani terlebih dahulu agar rumah tangga tidak menjadi tanpa pemilik.
- Firestore Rules mengizinkan anggota menghapus dokumen keanggotaannya sendiri.

## Uang SI 3.5.3 – Target Keluarga
- Menambahkan menu **Target** untuk mencatat tujuan keuangan seperti beli rumah, beli motor, dana pendidikan, dan liburan.
- Setiap target memiliki nominal tujuan, dana terkumpul, progres persentase, tanggal target opsional, dan catatan.
- Target tersimpan lokal pada database akun/perangkat dan memiliki migrasi Room 5 ke 6.
- Menampilkan label versi aplikasi **3.5.3** pada halaman login/daftar.
- `versionCode` dinaikkan menjadi 17; `versionName` tetap 3.5.3.
- Catatan: target belum disinkronkan antarperangkat/anggota keluarga dan belum dihitung otomatis dari transaksi.
