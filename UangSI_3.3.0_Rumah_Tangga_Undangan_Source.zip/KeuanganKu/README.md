# Uang SI 3.3.0 – Rumah Tangga & Undangan Pasangan

## Fitur tahap ini
- Menu Keluarga di navigasi aplikasi.
- Membuat rumah tangga di Cloud Firestore.
- Membuat kode undangan 6 digit.
- Pasangan dapat bergabung dengan kode undangan.
- Menyimpan householdId pada profil pengguna.

## Setup
1. Pastikan Firebase Authentication Email/Password aktif.
2. Pastikan Cloud Firestore dibuat.
3. Daftarkan aplikasi Android dengan package `id.keuanganku.app`.
4. Letakkan `google-services.json` di `app/google-services.json`.
5. Publikasikan aturan dari file `firestore.rules` pada tab Firestore > Rules.
6. Build menggunakan workflow GitHub Actions.

## Batasan tahap ini
Tahap 3.3.0 baru menyiapkan pembuatan rumah tangga dan undangan. Transaksi, dompet, anggaran, dan pembagian gaji masih disimpan lokal dan BELUM tersinkron otomatis antar-HP. Jangan menganggap saldo kedua pengguna sudah digabung. Sinkronisasi lintas perangkat akan menjadi tahap terpisah setelah alur keanggotaan diuji.

## Catatan keamanan
- Gunakan password kuat dan jangan membagikan OTP.
- Kode undangan hanya untuk pasangan.
- Tinjau Security Rules sebelum rilis publik.
- API key pada `google-services.json` bukan password, tetapi batasi API key di Google Cloud Console.
