# Uang SI 3.0 – tahap awal Firebase

Project Android Kotlin + Jetpack Compose. Integrasi pada tahap ini mencakup Firebase Authentication email/password, pemisahan database Room lokal per UID, dan konfigurasi Firebase project `keuanganku-online`.

## Build
Buka folder `KeuanganKu` di Android Studio atau gunakan workflow GitHub Actions. File `app/google-services.json` sudah disertakan.

## Firebase Console
Pastikan Authentication > Sign-in method > Email/Password aktif. Cloud Firestore sudah disiapkan, tetapi sinkronisasi transaksi dan grup rumah tangga belum diimplementasikan pada milestone ini.

## Catatan keamanan
Konfigurasi client Firebase bukan rahasia autentikasi. Jangan pernah memasukkan service-account private key, password, PIN, atau OTP ke aplikasi. Periksa dan perketat Firestore Security Rules sebelum menambahkan data cloud. Aturan saat ini harus divalidasi lagi untuk undangan anggota dan validasi skema.

## Fitur
- Registrasi dan login email/password Firebase.
- Logout.
- Database lokal terpisah per akun Firebase (mencegah data lokal akun berbeda bercampur pada perangkat yang sama).
- Fitur pencatatan, anggaran, laporan, dan backup lokal versi sebelumnya dipertahankan.

Belum termasuk: sinkronisasi Firestore transaksi, rumah tangga/invite code, alokasi gaji otomatis, dan koneksi bank.
