package id.keuanganku.app

import android.os.Bundle
import android.content.Context
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.*
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "transactions")
data class FinanceTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Long,
    val type: String,
    val category: String,
    val date: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey val category: String,
    val limitAmount: Long
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    suspend fun allTransactions(): List<FinanceTransaction>
    @Insert suspend fun insert(t: FinanceTransaction)
    @Update suspend fun update(t: FinanceTransaction)
    @Delete suspend fun delete(t: FinanceTransaction)
    @Query("SELECT * FROM budgets")
    suspend fun allBudgets(): List<Budget>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveBudget(b: Budget)
    @Query("DELETE FROM transactions") suspend fun clearTransactions()
    @Query("DELETE FROM budgets") suspend fun clearBudgets()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTransactions(items: List<FinanceTransaction>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBudgets(items: List<Budget>)
}

@Database(entities = [FinanceTransaction::class, Budget::class], version = 1, exportSchema = false)
data class FinanceBackup(
    val format: String = "KeuanganKuBackup",
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val transactions: List<FinanceTransaction>,
    val budgets: List<Budget>
)

abstract class FinanceDb : RoomDatabase() {
    abstract fun dao(): FinanceDao
    companion object {
        @Volatile private var INSTANCE: FinanceDb? = null
        fun get(context: android.content.Context): FinanceDb =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context, FinanceDb::class.java, "keuanganku.db").build().also { INSTANCE = it }
            }
    }
}

private val navy = Color(0xFF183B66)
private val pale = Color(0xFFF3F6FA)
private val green = Color(0xFF16845B)
private val red = Color(0xFFD94B4B)
private fun rupiah(v: Long): String = NumberFormat.getCurrencyInstance(Locale("in","ID")).format(v).replace(",00","")
private fun monthStart(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0)
    return c.timeInMillis
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = FinanceDb.get(this).dao()
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = navy, background = pale)) { FinanceApp(dao) } }
    }
}

@Composable
fun FinanceApp(dao: FinanceDao) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf(emptyList<FinanceTransaction>()) }
    var budgets by remember { mutableStateOf(emptyList<Budget>()) }
    var page by remember { mutableStateOf("Beranda") }
    var showForm by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<FinanceTransaction?>(null) }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Semua") }
    var pinEnabled by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<FinanceBackup?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val backup = FinanceBackup(transactions = dao.allTransactions(), budgets = dao.allBudgets())
                val json = Gson().toJson(backup)
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                        ?: error("File tujuan tidak dapat dibuka.")
                }
            }.onSuccess { backupMessage = "Backup berhasil disimpan." }
             .onFailure { backupMessage = "Gagal membuat backup: ${it.message ?: "kesalahan tidak diketahui"}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val json = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("File tidak dapat dibaca.")
                }
                val backup = Gson().fromJson(json, FinanceBackup::class.java) ?: error("Format file tidak valid.")
                validateBackup(backup)
                backup
            }.onSuccess { pendingRestore = it }
             .onFailure { backupMessage = "Backup ditolak: ${it.message ?: "file tidak valid"}" }
        }
    }

    suspend fun refresh() { rows = dao.allTransactions(); budgets = dao.allBudgets() }
    LaunchedEffect(Unit) { refresh() }

    val nowMonth = rows.filter { it.date >= monthStart() }
    val income = nowMonth.filter { it.type == "Pemasukan" }.sumOf { it.amount }
    val expense = nowMonth.filter { it.type == "Pengeluaran" }.sumOf { it.amount }
    val balance = rows.sumOf { if (it.type == "Pemasukan") it.amount else -it.amount }

    if (pinEnabled && !unlocked) {
        PinScreen(pin, { pin = it }, { if (it == pin) unlocked = true })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column { Text("KeuanganKu", fontWeight = FontWeight.Bold); Text("Kelola uang lebih teratur", fontSize = 12.sp, color = Color.Gray) } },
                actions = { IconButton(onClick = { showForm = true; edit = null }) { Icon(Icons.Default.Add, "Tambah") } }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Beranda","Transaksi","Anggaran","Laporan","Pengaturan").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item },
                        icon = { Icon(when(item) { "Beranda" -> Icons.Default.Home; "Transaksi" -> Icons.Default.ReceiptLong; "Anggaran" -> Icons.Default.Savings; "Laporan" -> Icons.Default.BarChart; else -> Icons.Default.Settings }, item) },
                        label = { Text(item) })
                }
            }
        },
        floatingActionButton = {
            if (page == "Beranda" || page == "Transaksi") FloatingActionButton(onClick = { edit = null; showForm = true }) { Icon(Icons.Default.Add, "Tambah transaksi") }
        }
    ) { pad ->
        when(page) {
            "Beranda" -> HomePage(Modifier.padding(pad), balance, income, expense, rows.take(5), { edit = it; showForm = true })
            "Transaksi" -> Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
                OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), label = { Text("Cari transaksi") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                Row(Modifier.padding(vertical=8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Semua","Pemasukan","Pengeluaran").forEach { FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it) }) }
                }
                TransactionList(rows.filter { (filter == "Semua" || it.type == filter) && (it.title.contains(search,true) || it.category.contains(search,true)) }, { edit = it; showForm = true }, { t -> scope.launch { dao.delete(t); refresh() } })
            }
            "Anggaran" -> BudgetPage(budgets, rows, { b -> scope.launch { dao.saveBudget(b); refresh() } }, Modifier.padding(pad))
            "Laporan" -> ReportPage(rows, Modifier.padding(pad))
            else -> SettingsPage(pinEnabled, { pinEnabled = it; if (!it) unlocked = false }, { pin = it; pinEnabled = true; unlocked = true }, { scope.launch { dao.clearTransactions(); dao.clearBudgets(); refresh() } }, rows, { exportLauncher.launch("KeuanganKu_backup.json") }, { importLauncher.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }, Modifier.padding(pad))
        }
    }
    pendingRestore?.let { backup ->
        AlertDialog(onDismissRequest = { pendingRestore = null },
            title = { Text("Pulihkan backup?") },
            text = { Text("Backup berisi ${backup.transactions.size} transaksi dan ${backup.budgets.size} anggaran. Pemulihan akan mengganti seluruh data yang ada saat ini. Pastikan Anda sudah memiliki salinan data terbaru.") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                    runCatching {
                        FinanceDb.get(context).withTransaction {
                            dao.clearTransactions(); dao.clearBudgets()
                            if (backup.transactions.isNotEmpty()) dao.insertTransactions(backup.transactions)
                            if (backup.budgets.isNotEmpty()) dao.insertBudgets(backup.budgets)
                        }
                        refresh()
                    }.onSuccess { backupMessage = "Data berhasil dipulihkan." }
                     .onFailure { backupMessage = "Pemulihan gagal: ${it.message ?: "kesalahan tidak diketahui"}" }
                    pendingRestore = null
                }
            }) { Text("Pulihkan", color = red) } },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Batal") } })
    }
    backupMessage?.let { message ->
        AlertDialog(onDismissRequest = { backupMessage = null }, title = { Text("Backup & Restore") },
            text = { Text(message) }, confirmButton = { TextButton(onClick = { backupMessage = null }) { Text("OK") } })
    }
    if (showForm) TransactionDialog(edit, onDismiss = { showForm = false }, onSave = { t ->
        scope.launch { if (t.id == 0L) dao.insert(t) else dao.update(t); refresh() }
        showForm = false
    })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomePage(modifier: Modifier, balance: Long, income: Long, expense: Long, recent: List<FinanceTransaction>, onEdit: (FinanceTransaction)->Unit) {
    Column(modifier.fillMaxSize().background(pale).padding(16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = navy), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Total saldo", color = Color.White.copy(alpha=.8f))
                Text(rupiah(balance), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Pemasukan bulan ini", color=Color.White.copy(alpha=.8f), fontSize=12.sp); Text(rupiah(income), color=Color.White, fontWeight=FontWeight.SemiBold) }
                    Column { Text("Pengeluaran bulan ini", color=Color.White.copy(alpha=.8f), fontSize=12.sp); Text(rupiah(expense), color=Color.White, fontWeight=FontWeight.SemiBold) }
                }
            }
        }
        Text("Transaksi terbaru", Modifier.padding(top=22.dp,bottom=8.dp), fontWeight=FontWeight.Bold, fontSize=18.sp)
        TransactionList(recent, onEdit, {})
    }
}

@Composable
fun TransactionList(rows: List<FinanceTransaction>, onEdit: (FinanceTransaction)->Unit, onDelete: (FinanceTransaction)->Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(rows, key = { it.id }) { t ->
            Card(Modifier.fillMaxWidth().clickable { onEdit(t) }, colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(if(t.type=="Pemasukan") Color(0xFFE4F5EC) else Color(0xFFFFEAEA), RoundedCornerShape(13.dp)), contentAlignment=Alignment.Center) {
                        Icon(if(t.type=="Pemasukan") Icons.Default.TrendingUp else Icons.Default.TrendingDown, null, tint=if(t.type=="Pemasukan") green else red)
                    }
                    Column(Modifier.weight(1f).padding(start=12.dp)) {
                        Text(t.title, fontWeight=FontWeight.SemiBold)
                        Text("${t.category} • ${SimpleDateFormat("dd MMM yyyy", Locale("id")).format(Date(t.date))}", color=Color.Gray, fontSize=12.sp)
                    }
                    Column(horizontalAlignment=Alignment.End) {
                        Text((if(t.type=="Pemasukan") "+" else "-") + rupiah(t.amount), color=if(t.type=="Pemasukan") green else red, fontWeight=FontWeight.Bold)
                        if (onDelete !== {}) { /* delete action available in transaction editor */ }
                    }
                }
            }
        }
        if(rows.isEmpty()) item { Text("Belum ada transaksi. Tekan tombol + untuk mulai mencatat.", color=Color.Gray, modifier=Modifier.padding(20.dp)) }
    }
}

@Composable
fun TransactionDialog(existing: FinanceTransaction?, onDismiss:()->Unit, onSave:(FinanceTransaction)->Unit) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.toString() ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: "Pengeluaran") }
    var category by remember { mutableStateOf(existing?.category ?: "Makan") }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    val categories = if(type=="Pemasukan") listOf("Gaji","Bonus","Usaha","Investasi","Lainnya") else listOf("Makan","Transportasi","Belanja","Tagihan","Kesehatan","Hiburan","Pendidikan","Rumah","Lainnya")
    AlertDialog(onDismissRequest=onDismiss, title={Text(if(existing==null) "Tambah transaksi" else "Edit transaksi")}, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FilterChip(type=="Pemasukan",{type="Pemasukan";category="Gaji"},{Text("Pemasukan")}); FilterChip(type=="Pengeluaran",{type="Pengeluaran";category="Makan"},{Text("Pengeluaran")}) }
            OutlinedTextField(title,{title=it},label={Text("Nama transaksi")},singleLine=true)
            OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Nominal (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
            Text("Kategori", fontWeight=FontWeight.SemiBold)
            Column { categories.chunked(3).forEach { group -> Row { group.forEach { c -> FilterChip(category==c,{category=c},{Text(c)}, modifier=Modifier.padding(end=4.dp)) } } } }
            OutlinedTextField(note,{note=it},label={Text("Catatan (opsional)")})
        }
    }, confirmButton={ TextButton(onClick={ val n=amount.toLongOrNull() ?: 0L; if(title.isNotBlank() && n>0) onSave(FinanceTransaction(existing?.id ?: 0,title,n,type,category,existing?.date ?: System.currentTimeMillis(),note)) }) { Text("Simpan") } }, dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})
}

@Composable
fun BudgetPage(budgets: List<Budget>, rows: List<FinanceTransaction>, onSave:(Budget)->Unit, modifier:Modifier=Modifier) {
    var category by remember { mutableStateOf("Makan") }
    var limit by remember { mutableStateOf("") }
    val spent = rows.filter { it.type=="Pengeluaran" && it.date>=monthStart() }.groupBy { it.category }.mapValues { it.value.sumOf { t -> t.amount } }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Anggaran bulanan", fontSize=21.sp, fontWeight=FontWeight.Bold)
        Text("Atur batas pengeluaran untuk setiap kategori.", color=Color.Gray)
        OutlinedTextField(category,{category=it},label={Text("Kategori")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(limit,{limit=it.filter(Char::isDigit)},label={Text("Batas anggaran (Rp)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        Button(onClick={ limit.toLongOrNull()?.takeIf{it>0}?.let{onSave(Budget(category.trim(),it));limit=""} },modifier=Modifier.padding(vertical=8.dp)) { Text("Simpan anggaran") }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(budgets) { b ->
                val used=spent[b.category] ?: 0L
                val progress=(used.toFloat()/b.limitAmount.toFloat()).coerceIn(0f,1f)
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(b.category,fontWeight=FontWeight.Bold); Text("${(progress*100).toInt()}%") }
                    LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp))
                    Text("${rupiah(used)} dari ${rupiah(b.limitAmount)}",fontSize=12.sp,color=Color.Gray)
                } }
            }
        }
    }
}

@Composable
fun ReportPage(rows: List<FinanceTransaction>, modifier:Modifier=Modifier) {
    val monthly=rows.filter { it.date>=monthStart() }
    val inc=monthly.filter{it.type=="Pemasukan"}.sumOf{it.amount}
    val exp=monthly.filter{it.type=="Pengeluaran"}.sumOf{it.amount}
    val byCat=monthly.filter{it.type=="Pengeluaran"}.groupBy{it.category}.mapValues{it.value.sumOf{t->t.amount}}.toList().sortedByDescending{it.second}
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Laporan bulan ini",fontSize=21.sp,fontWeight=FontWeight.Bold)
        SummaryLine("Total pemasukan",inc,green); SummaryLine("Total pengeluaran",exp,red); SummaryLine("Selisih",inc-exp,navy)
        Text("Pengeluaran per kategori",fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(top=18.dp,bottom=8.dp))
        byCat.forEach { (cat,amt) ->
            Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween) { Text(cat); Text(rupiah(amt),fontWeight=FontWeight.SemiBold) }
            LinearProgressIndicator(progress={if(exp==0L) 0f else amt.toFloat()/exp},modifier=Modifier.fillMaxWidth())
        }
        if(byCat.isEmpty()) Text("Belum ada data pengeluaran bulan ini.",color=Color.Gray)
    }
}
@Composable fun SummaryLine(label:String, value:Long, color:Color) {
    Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) { Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text(label); Text(rupiah(value),fontWeight=FontWeight.Bold,color=color) } }
}

private fun validateBackup(backup: FinanceBackup) {
    require(backup.format == "KeuanganKuBackup") { "File bukan backup KeuanganKu." }
    require(backup.version == 1) { "Versi backup tidak didukung." }
    require(backup.transactions.size <= 100_000) { "Jumlah transaksi terlalu besar." }
    require(backup.budgets.size <= 10_000) { "Jumlah anggaran terlalu besar." }
    require(backup.transactions.all { it.id >= 0L && it.title.isNotBlank() && it.amount > 0L && it.type in setOf("Pemasukan", "Pengeluaran") && it.category.isNotBlank() && it.date > 0L }) { "Data transaksi tidak valid." }
    require(backup.transactions.map { it.id }.distinct().size == backup.transactions.size) { "ID transaksi duplikat." }
    require(backup.budgets.all { it.category.isNotBlank() && it.limitAmount > 0L }) { "Data anggaran tidak valid." }
    require(backup.budgets.map { it.category }.distinct().size == backup.budgets.size) { "Kategori anggaran duplikat." }
}

@Composable
fun SettingsPage(pinEnabled:Boolean,onPinToggle:(Boolean)->Unit,onSetPin:(String)->Unit,onClear:()->Unit,rows:List<FinanceTransaction>,onExport:()->Unit,onImport:()->Unit,modifier:Modifier=Modifier) {
    var newPin by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Pengaturan",fontSize=22.sp,fontWeight=FontWeight.Bold)
        Text("Keamanan",fontWeight=FontWeight.Bold)
        Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Kunci PIN"); Text("Minta PIN saat membuka aplikasi",fontSize=12.sp,color=Color.Gray) }; Switch(pinEnabled,{onPinToggle(it)}) }
        OutlinedTextField(newPin,{newPin=it.filter(Char::isDigit).take(6)},label={Text("Atur PIN 4–6 angka")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        Button(onClick={if(newPin.length in 4..6) onSetPin(newPin)},enabled=newPin.length in 4..6){Text("Simpan PIN")}
        Divider()
        Text("Data",fontWeight=FontWeight.Bold)
        Text("Data disimpan secara offline di penyimpanan aplikasi. Total ${rows.size} transaksi.")
        OutlinedButton(onClick=onExport, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Cadangkan data (JSON)") }
        OutlinedButton(onClick=onImport, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Pulihkan dari file backup") }
        Text("Backup menyimpan transaksi dan anggaran. Pemulihan mengganti data lokal setelah konfirmasi.",fontSize=12.sp,color=Color.Gray)
        OutlinedButton(onClick={confirmClear=true},colors=ButtonDefaults.outlinedButtonColors(contentColor=red)){Text("Hapus seluruh data")}
    }
    if(confirmClear) AlertDialog(onDismissRequest={confirmClear=false},title={Text("Hapus semua data?")},text={Text("Semua transaksi dan anggaran akan dihapus permanen.")},confirmButton={TextButton(onClick={onClear;confirmClear=false}){Text("Hapus",color=red)}},dismissButton={TextButton(onClick={confirmClear=false}){Text("Batal")}})
}

@Composable
fun PinScreen(pin:String,onPinChange:(String)->Unit,onUnlock:(String)->Unit) {
    var entered by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(pale).padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
        Icon(Icons.Default.Lock,null,tint=navy,modifier=Modifier.size(48.dp))
        Text("KeuanganKu terkunci",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(12.dp))
        OutlinedTextField(entered,{entered=it.filter(Char::isDigit).take(6)},label={Text("Masukkan PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        Button(onClick={onUnlock(entered)},modifier=Modifier.padding(12.dp)){Text("Buka")}
        Text("PIN awal belum tersinkron jika aplikasi baru dipasang.",fontSize=11.sp,color=Color.Gray)
    }
}
